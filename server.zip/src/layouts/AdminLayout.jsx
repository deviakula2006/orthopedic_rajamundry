import React from 'react';
import AppLayout from './AppLayout';

const AdminLayout = () => {
  return <AppLayout />;
};

export default AdminLayout;
