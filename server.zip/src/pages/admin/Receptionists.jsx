import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { Table } from '../../components/ui/Table';
import { Modal } from '../../components/ui/Modal';
import { Plus, Edit, Trash2, Clock } from 'lucide-react';
import ThreeDotMenu from '../../components/common/ThreeDotMenu';
import ConfirmationModal from '../../components/common/ConfirmationModal';

const Receptionists = () => {
  const {
    receptionists,
    addReceptionist,
    editReceptionist,
    deleteReceptionist,
    showToast
  } = useHospital();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedRec, setSelectedRec] = useState(null);

  // Confirmation Modals State
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [statusConfirmOpen, setStatusConfirmOpen] = useState(false);
  const [selectedRecId, setSelectedRecId] = useState('');
  const [recToToggle, setRecToToggle] = useState(null);

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    shift: 'Morning (8 AM - 4 PM)',
    status: 'Active'
  });

  const handleOpenAdd = () => {
    setFormData({
      name: '',
      phone: '',
      email: '',
      shift: 'Morning (8 AM - 4 PM)',
      status: 'Active',
      password: ''
    });
    setIsAddOpen(true);
  };

  const handleOpenEdit = (rec) => {
    setSelectedRec(rec);
    setFormData({
      name: rec.name,
      phone: rec.phone,
      email: rec.email,
      shift: rec.shift,
      status: rec.status
    });
    setIsEditOpen(true);
  };

 const handleAddSubmit = async (e) => {
  e.preventDefault();

  const createdReceptionist = await addReceptionist(formData);

  if (createdReceptionist) {
    setIsAddOpen(false);
  }
};

const handleEditSubmit = async (e) => {
  e.preventDefault();

  if (!selectedRec) {
    return;
  }

  const updatedReceptionist = await editReceptionist(
    selectedRec.id,
    formData
  );

  if (updatedReceptionist) {
    setIsEditOpen(false);
    setSelectedRec(null);
  }
};

const triggerStatusToggle = (rec) => {
  setRecToToggle(rec);
  setStatusConfirmOpen(true);
};

const handleConfirmStatusToggle = async () => {
  if (!recToToggle) {
    return;
  }

  const newStatus =
    recToToggle.status === 'Active' ? 'Inactive' : 'Active';

  const updatedReceptionist = await editReceptionist(
    recToToggle.id,
    {
      name: recToToggle.name,
      phone: recToToggle.phone,
      email: recToToggle.email,
      shift: recToToggle.shift,
      status: newStatus
    }
  );

  if (updatedReceptionist) {
    setStatusConfirmOpen(false);
    setRecToToggle(null);
  }
};

const triggerDelete = (id) => {
  setSelectedRecId(id);
  setDeleteConfirmOpen(true);
};

const handleConfirmDelete = async () => {
  if (!selectedRecId) {
    return;
  }

  const deleted = await deleteReceptionist(selectedRecId);

  if (deleted) {
    setDeleteConfirmOpen(false);
    setSelectedRecId('');
  }
};

  const columns = [
    {
      key: 'id',
      header: 'Staff ID',
      sortable: true,
      render: (row) => <span className="font-bold text-slate-500">{row.id}</span>
    },
    {
      key: 'name',
      header: 'Receptionist Name',
      sortable: true,
      render: (row) => (
        <div>
          <span className="font-bold text-slate-800 block">{row.name}</span>
          <span className="text-[10px] font-semibold text-slate-400 block">{row.email}</span>
        </div>
      )
    },
    {
      key: 'phone',
      header: 'Phone Number'
    },
    {
      key: 'shift',
      header: 'Duty Shift',
      render: (row) => (
        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold">
          <Clock className="h-3.5 w-3.5 text-slate-400" />
          <span>{row.shift}</span>
        </div>
      )
    },
    {
      key: 'status',
      header: 'Access Status',
      sortable: true,
      render: (row) => (
        <button
          type="button"
          onClick={() => triggerStatusToggle(row)}
          className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold transition-all border cursor-pointer ${
            row.status === 'Active'
              ? 'bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100'
              : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
          }`}
          title="Click to toggle status"
        >
          <span
            className={`h-1.5 w-1.5 rounded-full ${
              row.status === 'Active' ? 'bg-emerald-500' : 'bg-slate-400'
            }`}
          ></span>
          {row.status}
        </button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-end">
        
        <button
          type="button"
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 self-start rounded-xl bg-gradient-to-r from-hospital-500 to-cyanic-500 px-4 py-2.5 text-sm font-bold text-white shadow-premium hover:shadow-premium-hover transition-all focus:outline-none cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Add Receptionist</span>
        </button>
      </div>

      {/* Main Table */}
      <Table
        columns={columns}
        data={receptionists}
        searchPlaceholder="Search staff by name or email..."
        searchKey="name"
        emptyMessage="No receptionists registered in roster"
        itemsPerPage={6}
        actions={(row) => (
          <ThreeDotMenu
            options={[
              {
                label: 'Edit Details',
                icon: Edit,
                onClick: () => handleOpenEdit(row)
              },
              {
                label: 'Remove Access',
                icon: Trash2,
                destructive: true,
                onClick: () => triggerDelete(row.id)
              }
            ]}
          />
        )}
      />

      {/* Modal: Add Receptionist */}
      <Modal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} title="Register Roster Staff" size="md">
        <form onSubmit={handleAddSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Staff Name
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Kishore Kumar"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Duty Shift
              </label>
              <select
                value={formData.shift}
                onChange={(e) => setFormData({ ...formData, shift: e.target.value })}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all cursor-pointer font-semibold"
              >
                <option value="Morning (8 AM - 4 PM)">Morning (8 AM - 4 PM)</option>
                <option value="Evening (4 PM - 12 AM)">Evening (4 PM - 12 AM)</option>
                <option value="Night (12 AM - 8 AM)">Night (12 AM - 8 AM)</option>
              </select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Phone Number
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="e.g. 9876543219"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="e.g. kishore.k@roh.com"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Login Password
            </label>
            <input
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="Min 8 characters"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-500 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-hospital-500 text-xs font-bold text-white shadow-premium hover:bg-hospital-600 cursor-pointer"
            >
              Add Staff
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal: Edit Receptionist */}
      <Modal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} title="Modify Staff Access" size="md">
        <form onSubmit={handleEditSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Staff Name
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Duty Shift
              </label>
              <select
                value={formData.shift}
                onChange={(e) => setFormData({ ...formData, shift: e.target.value })}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all cursor-pointer font-semibold"
              >
                <option value="Morning (8 AM - 4 PM)">Morning (8 AM - 4 PM)</option>
                <option value="Evening (4 PM - 12 AM)">Evening (4 PM - 12 AM)</option>
                <option value="Night (12 AM - 8 AM)">Night (12 AM - 8 AM)</option>
              </select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Phone Number
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-3.5 text-sm font-semibold text-slate-700 focus:border-hospital-500 focus:bg-white focus:outline-none transition-all"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsEditOpen(false)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-500 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-hospital-500 text-xs font-bold text-white shadow-premium hover:bg-hospital-600 cursor-pointer"
            >
              Save Details
            </button>
          </div>
        </form>
      </Modal>

      {/* Confirmation: Toggle Status */}
      <ConfirmationModal
        isOpen={statusConfirmOpen}
        onClose={() => setStatusConfirmOpen(false)}
        onConfirm={handleConfirmStatusToggle}
        title="Toggle Staff Status"
        message={`Are you sure you want to toggle shift duties status for ${
          recToToggle ? recToToggle.name : 'this staff'
        }?`}
        confirmText="Confirm Toggle"
        type="warning"
      />

      {/* Confirmation: Delete */}
      <ConfirmationModal
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Remove Staff Access"
        message="Are you sure you want to terminate receptionist portal credentials? This action is irreversible."
        confirmText="Remove Access"
        type="danger"
      />
    </div>
  );
};

export default Receptionists;
